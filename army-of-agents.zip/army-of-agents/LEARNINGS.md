# Learnings - army-of-agents

## Histórico de Correções

Registro automático de erros corrigidos nesta skill.

---

### 2025-01-08 - Skill reorganization with progressive disclosure

**Problema:** SKILL.md tinha 65+ linhas com muito conteúdo técnico, REFERENCE.md e EXAMPLES.md soltos na raiz
**Correção:** Reorganizado para progressive disclosure - SKILL.md minimalista (<90 linhas), conteúdo técnico movido para references/, adicionado sistema auto-correção
**Linha afetada:** SKILL.md (completo), REFERENCE.md → references/roles.md, EXAMPLES.md → references/examples.md
**Status:** ✅ Corrigido

---
