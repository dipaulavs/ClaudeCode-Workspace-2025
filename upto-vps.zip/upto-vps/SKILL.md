---
name: upto-vps
description: Deploy any application or website to VPS (82.25.68.132) with automatic SSL certificates via Traefik and Docker Swarm. Auto-invokes when user requests to deploy, upload, or put online any web application, API, dashboard, or site. Handles GitHub setup, docker-compose configuration with correct Traefik labels, SSL validation, and ensures no conflicts with existing services.
---

# Upto VPS

## Overview

Deploy applications to production VPS with automatic SSL certificates and zero downtime. This skill automates the entire deployment workflow: GitHub repository setup, Docker Swarm deployment with Traefik reverse proxy, Let's Encrypt SSL certificate provisioning, and validation. Ensures deployments don't conflict with 40+ existing services running on the VPS.

## When to Use This Skill

Auto-invoke when user requests:
- "Deploy this to the VPS"
- "Put this site online"
- "Upload this app to production"
- "I need SSL for this"
- "Make this accessible at <subdomain>.loop9.com.br"
- "Set up production deployment"

## Core Workflow

### Step 1: Prepare Application

1. **Identify application type** (Flask/Node/Static/etc.)
2. **Detect port** application runs on
3. **Check for existing docker-compose.yml**
   - If exists: Validate Traefik labels configuration
   - If missing: Create from template

### Step 2: Configure Docker Compose

Read `references/traefik_labels.md` for correct configuration, then apply:

**Critical requirements:**
- Labels must be under `deploy.labels` (not service top-level)
- Use `letsencryptresolver` as certresolver name
- Include explicit service reference: `.service=<service-name>`
- Never add `tls=true` (causes default certificate)
- Network must be `loop9Net` (external)

**Template variables to replace:**
- `{{SERVICE_NAME}}` - Router/service identifier (e.g., "lfimoveis")
- `{{SUBDOMAIN}}` - Domain prefix (e.g., "lfimoveis" for lfimoveis.loop9.com.br)
- `{{PORT}}` - Application internal port
- `{{IMAGE}}` - Docker image name
- `{{COMMAND}}` - Container startup command
- `{{ENVIRONMENT}}` - Environment variables

Use `assets/docker-compose.template.yml` as base.

### Step 3: GitHub Setup

```bash
# Initialize if needed
git init
git remote add origin https://github.com/dipaulavs/<repo-name>.git

# Commit current state
git add .
git commit -m "feat: initial deployment setup"
git push origin main
```

If repository doesn't exist, create it first:
```bash
gh repo create <repo-name> --public --source=. --remote=origin --push
```

### Step 4: VPS Deployment

**Initial deployment:**
```bash
ssh root@82.25.68.132 "cd /root && git clone https://github.com/dipaulavs/<repo-name>.git <project-name>"
ssh root@82.25.68.132 "cd /root/<project-name> && docker stack deploy -c docker-compose.yml <stack-name>"
```

**Update existing deployment:**
```bash
# Method 1: Force update (preserves state)
ssh root@82.25.68.132 "cd /root/<project> && git pull && docker service update --force <stack>_app"

# Method 2: Full recreation (if SSL issues)
ssh root@82.25.68.132 "cd /root/<project> && git pull && docker stack rm <stack> && sleep 10 && docker stack deploy -c docker-compose.yml <stack>"
```

### Step 5: Validation

**Check service status:**
```bash
ssh root@82.25.68.132 "docker service ls | grep <stack-name>"
ssh root@82.25.68.132 "docker service logs <stack-name>_app --tail 50"
```

**Validate SSL certificate:**
```bash
bash scripts/validate_ssl.sh <subdomain>.loop9.com.br
```

Expected output:
```
issuer=C=US, O=Let's Encrypt, CN=R12
subject=CN=<subdomain>.loop9.com.br
```

If shows "TRAEFIK DEFAULT CERT", SSL failed. Perform full stack recreation (Step 4, Method 2).

**Test endpoints:**
```bash
# HTTP should redirect to HTTPS
curl -I http://<subdomain>.loop9.com.br

# HTTPS should return 200 OK
curl -I https://<subdomain>.loop9.com.br
```

## Troubleshooting

### SSL Shows "Not Secure" in Browser

**Cause:** Browser cached old certificate

**Solutions:**
1. Clear SSL state: `chrome://net-internals/#hsts` → Delete domain
2. Clear browser cache (last hour)
3. Hard refresh: Cmd+Shift+R (Mac) or Ctrl+Shift+R (Windows)
4. Test in incognito/private window
5. Wait 2-3 minutes for full propagation

### Certificate Shows "TRAEFIK DEFAULT CERT"

**Cause:** Traefik labels misconfigured

**Fix:**
1. Verify labels are under `deploy.labels` (not top level)
2. Check certresolver is `letsencryptresolver` (not `letsencrypt`)
3. Remove `tls=true` if present
4. Verify service reference: `.service=<service-name>`
5. Full recreation required:
```bash
ssh root@82.25.68.132 "docker stack rm <stack> && sleep 10 && docker stack deploy -c docker-compose.yml <stack>"
```

### Port Conflict

**Check existing services:**
```bash
ssh root@82.25.68.132 "docker service ls"
```

Read `references/vps_info.md` for list of used ports. Use different internal port if needed.

### Service Won't Start

**Check logs:**
```bash
ssh root@82.25.68.132 "docker service ps <stack>_app --no-trunc"
ssh root@82.25.68.132 "docker service logs <stack>_app"
```

Common issues:
- Missing dependencies in requirements.txt/package.json
- Wrong working directory
- Port already bound
- Environment variables not set

## Naming Conventions

- **Stack name:** kebab-case (e.g., `lf-dashboard`, `my-api`)
- **Service name:** Usually `app` for single-service stacks
- **Router name:** Match subdomain without domain suffix (e.g., `lfimoveis` for lfimoveis.loop9.com.br)
- **Subdomain:** Short, descriptive, kebab-case

## Reference Files

- **references/traefik_labels.md** - Complete Traefik labels configuration with working examples
- **references/vps_info.md** - VPS details, existing services, troubleshooting guide
- **assets/docker-compose.template.yml** - Base template with correct structure

## Quick Reference Commands

```bash
# List all services on VPS
ssh root@82.25.68.132 "docker service ls"

# Check service logs
ssh root@82.25.68.132 "docker service logs <service-name> --tail 50"

# Inspect service labels
ssh root@82.25.68.132 "docker service inspect <service> --format '{{json .Spec.Labels}}' | jq ."

# Remove stack
ssh root@82.25.68.132 "docker stack rm <stack-name>"

# Validate SSL
bash scripts/validate_ssl.sh <subdomain>.loop9.com.br
```

## Auto-Correction System

When deployment fails, use auto-correction to prevent recurrence:

```bash
# Fix SKILL.md
python3 scripts/update_skill.py <old_text> <new_text>

# Log the fix
python3 scripts/log_learning.py <error> <fix> <line>
```

All corrections are tracked in `LEARNINGS.md`.
