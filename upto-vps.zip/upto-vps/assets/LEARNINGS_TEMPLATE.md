# Learnings - {SKILL_NAME}

Este arquivo registra todos os erros corrigidos e aprendizados adquiridos durante o uso desta skill.

## Objetivo

Prevenir que os mesmos erros aconteçam novamente, mantendo histórico de:
- Problemas encontrados
- Correções aplicadas
- Linhas/arquivos afetados
- Status da correção

---

## Histórico de Correções

<!-- As correções mais recentes aparecem primeiro -->
